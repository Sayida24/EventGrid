<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

// 1. Security Check
if (!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }
$user_id = $_SESSION['user_id'];

// 2. Get the Event ID from the URL
if(!isset($_GET['id'])) { header("Location: dashboard.php"); exit(); }
$event_id = mysqli_real_escape_string($conn, $_GET['id']);

// 3. Fetch Event Details
$query = "SELECT * FROM events WHERE id = '$event_id'";
$result = mysqli_query($conn, $query);
$event = mysqli_fetch_assoc($result);

if(!$event) { die("Event not found."); }

// 4. Fetch Registration status (for regular events)
$check_reg = mysqli_query($conn, "SELECT id FROM registrations WHERE user_id = '$user_id' AND event_id = '$event_id'");
$is_registered = (mysqli_num_rows($check_reg) > 0);

// 5. Fetch Stall Application details (for Startup events)
$stall_res = mysqli_query($conn, "SELECT id, status, payment_status FROM stall_applications 
                                  WHERE user_id = '$user_id' AND event_id = '$event_id'");
$stall_data = mysqli_fetch_assoc($stall_res);

// 6. NEW: Fetch Volunteer Application status
$vol_res = mysqli_query($conn, "SELECT status FROM volunteer_apps WHERE user_id = '$user_id' AND event_id = '$event_id'");
$vol_data = mysqli_fetch_assoc($vol_res);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($event['title']); ?> | EventGrid</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header"><h2>EventGrid</h2><p>Student Portal</p></div>
        <nav class="admin-nav">
            <a href="dashboard.php">🏠 Explore Events</a>
            <a href="my_registrations.php">📅 My Registrations</a>
            <a href="my_stalls.php">🛒 Stall Status</a>
            <a href="notification.php">🔔 Notifications</a>
            <a href="feedback.php">💬 Suggestions</a>
            <a href="logout.php">Logout</a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="details-card">
            <div class="details-image-container">
                <img src="uploads/<?php echo $event['poster']; ?>" alt="Poster">
            </div>

            <div style="padding: 30px;">
                <span class="badge"><?php echo $event['event_type']; ?></span>
                <h1 style="margin: 15px 0; color: #2d3748;"><?php echo htmlspecialchars($event['title']); ?></h1>

                <div class="details-info-row">
                    <div class="info-box">
                        <small style="color: gray; font-weight: bold;">DATE</small>
                        <p style="margin: 5px 0 0 0; font-weight: 600;">📅 <?php echo date('M d, Y', strtotime($event['event_date'])); ?></p>
                    </div>
                    <div class="info-box">
                        <small style="color: gray; font-weight: bold;">VENUE</small>
                        <p style="margin: 5px 0 0 0; font-weight: 600;">📍 <?php echo htmlspecialchars($event['location']); ?></p>
                    </div>
                </div>

                <div style="margin-bottom: 30px;">
                    <h3>About this Event</h3>
                    <p style="color: #4a5568; line-height: 1.6;">
                        This is a university <?php echo strtolower($event['event_type']); ?>. 
                        <?php if($event['event_type'] == 'Startup Market'): ?>
                            <strong>Startup Rule:</strong> Submit your business details for selection. Once approved, you must pay the booking fee to secure your spot.
                        <?php else: ?>
                            Register to confirm your attendance and receive your university food coupon.
                        <?php endif; ?>
                    </p>
                </div>

                <!-- ==========================================
                     DYNAMIC ACTION BUTTONS
                     ========================================== -->
                <div style="border-top: 1px solid #edf2f7; padding-top: 25px; display: flex; flex-direction: column; gap: 15px;">
                    
                    <!-- 1. STALL LOGIC (UNCHANGED) -->
                    <?php if($event['event_type'] == 'Startup Market'): ?>
                        <?php if(!$stall_data): ?>
                            <a href="apply_stall.php?eid=<?php echo $event['id']; ?>" class="btn-publish" style="text-decoration:none; display:block; text-align:center; background: #805ad5;">Apply for Startup Stall</a>
                        <?php elseif($stall_data['status'] == 'pending'): ?>
                            <div style="background: #fff3cd; color: #856404; padding: 15px; border-radius: 10px; text-align: center; font-weight: 600; border: 1px solid #ffeeba;">⚠️ Application Pending. Admin is reviewing your business page.</div>
                        <?php elseif($stall_data['status'] == 'approved' && $stall_data['payment_status'] == 'unpaid'): ?>
                            <div style="background: #e6fffa; color: #2c7a7b; padding: 20px; border-radius: 10px; text-align: center; border: 1px solid #b2f5ea;"><p style="margin-bottom: 10px; font-weight: bold;">🎉 You have been selected!</p>
                            <a href="payment.php?app_id=<?php echo $stall_data['id']; ?>" class="btn-publish" style="text-decoration:none; display:block; text-align:center; background: #38a169;">Proceed to Payment (500 BDT)</a></div>
                        <?php elseif($stall_data['payment_status'] == 'paid'): ?>
                            <div style="background: #f0fff4; color: #2f855a; padding: 15px; border-radius: 10px; text-align: center; font-weight: 600; border: 1px solid #c6f6d5;">✅ Stall Confirmed & Payment Verified!</div>
                        <?php elseif($stall_data['status'] == 'rejected'): ?>
                            <div style="background: #fff5f5; color: #c53030; padding: 15px; border-radius: 10px; text-align: center; font-weight: 600; border: 1px solid #fed7d7;">❌ Sorry, your stall application was not selected.</div>
                        <?php endif; ?>

                    <!-- 2. REGULAR REGISTRATION LOGIC (UNCHANGED) -->
                    <?php else: ?>
                        <?php if($is_registered): ?>
                            <div style="background: #f0fff4; color: #2f855a; padding: 15px; border-radius: 10px; text-align: center; font-weight: 600; border: 1px solid #c6f6d5;">✅ You are registered for this event!</div>
                        <?php else: ?>
                            <a href="join_event.php?event_id=<?php echo $event['id']; ?>" class="btn-publish" style="text-decoration:none; display:block; text-align:center;">Confirm Registration</a>
                        <?php endif; ?>
                    <?php endif; ?>

                    <!-- 3. VOLUNTEER LOGIC (NEW SECTION) -->
                    <?php if($event['volunteers_needed'] == 1): ?>
                        <?php if($vol_data): ?>
                            <div style="background: #e6fffa; color: #2c7a7b; padding: 12px; border-radius: 10px; text-align: center; font-weight: 600; border: 1px solid #b2f5ea;">
                                ✅ Volunteer Application: <?php echo strtoupper($vol_data['status']); ?>
                            </div>
                        <?php else: ?>
                            <a href="apply_volunteer.php?eid=<?php echo $event['id']; ?>" class="btn-publish" style="text-decoration:none; display:block; text-align:center; background: #38a169;">
                                Apply to Volunteer for this Event
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </main>
</div>

</body>
</html>