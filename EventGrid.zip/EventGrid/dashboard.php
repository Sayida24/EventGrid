<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

// 1. Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// 2. POPUP LOGIC: Show alert for the newest event if user hasn't dismissed it
$latest_q = mysqli_query($conn, "SELECT id, title FROM events ORDER BY id DESC LIMIT 1");
$latest_event = mysqli_fetch_assoc($latest_q);
$latest_id = $latest_event ? $latest_event['id'] : 0;

$user_q = mysqli_query($conn, "SELECT last_seen_event_id FROM users WHERE id = '$user_id'");
$user_data = mysqli_fetch_assoc($user_q);
$last_seen = $user_data['last_seen_event_id'];

$show_popup = ($latest_id > $last_seen) ? true : false;

// 3. STATS: Fetch registration count for the header
$my_regs = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM registrations WHERE user_id = '$user_id'"));

// 4. FETCH ALL EVENTS for the Grid
$events_res = mysqli_query($conn, "SELECT * FROM events ORDER BY event_date ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Explore Events | EventGrid</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- STUDENT SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header"><h2>EventGrid</h2><p>Student Portal</p></div>
        <nav class="admin-nav">
            <a href="dashboard.php" class="active">🏠 Explore Events</a>
            <a href="my_registrations.php">📅 My Registrations</a>
            <a href="my_stalls.php">🛒 Stall Status</a> 
            <a href="notification.php">🔔 Notifications</a>
            <a href="feedback.php">💬 Suggestions</a>
            <a href="logout.php">🚪 Logout</a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <div>
                <h1>Welcome, <?php echo $_SESSION['name']; ?>!</h1>
                <p>Browse upcoming events and university activities.</p>
            </div>
            <!-- Statistics Card -->
            <div style="background: white; padding: 15px 25px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); text-align: center;">
                <small style="color: #718096; font-weight: bold; text-transform: uppercase; font-size: 0.7rem;">Events Joined</small>
                <span style="font-size: 1.8rem; font-weight: 800; color: #3182ce; display: block;"><?php echo $my_regs; ?></span>
            </div>
        </div>

        <!-- SUCCESS MESSAGE ALERT (from registration/apply) -->
        <?php if(isset($_GET['msg'])): ?>
            <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 5px solid #28a745;">
                ✅ <?php echo htmlspecialchars($_GET['msg']); ?>
            </div>
        <?php endif; ?>

        <!-- EXPLORE EVENTS GRID (2 COLUMNS) -->
        <h2 style="margin-bottom: 25px; color: #2d3748;">Upcoming Events</h2>
        
        <div class="student-event-grid">
            <?php if (mysqli_num_rows($events_res) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($events_res)): ?>
                    
                    <div class="student-event-card">
                        <div class="card-img-container">
                            <img src="uploads/<?php echo $row['poster']; ?>" alt="Poster">
                            <span class="type-badge"><?php echo $row['event_type']; ?></span>
                        </div>
                        <div class="card-text-content">
                            <h3><?php echo $row['title']; ?></h3>
                            <p class="venue-text">📍 <?php echo $row['location']; ?></p>
                            <p class="date-text">📅 <?php echo date('M d, Y', strtotime($row['event_date'])); ?></p>
                            <a href="event_details.php?id=<?php echo $row['id']; ?>" class="view-btn">View Details & Register</a>
                        </div>
                    </div>

                <?php endwhile; ?>
            <?php else: ?>
                <div style="grid-column: span 2; text-align: center; padding: 50px; background: white; border-radius: 15px;">
                    <p>No events found at the moment. Check back later!</p>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<!-- SMART POPUP ALERT -->
<?php if($show_popup && $latest_event): ?>
<div class="notif-popup-overlay" id="simpleNotif">
    <div class="notif-popup-box">
        <h2>New Event Alert!</h2>
        <p>A new event "<strong><?php echo htmlspecialchars($latest_event['title']); ?></strong>" was just posted by the Admin.</p>
        <div style="display: flex; gap: 10px;">
            <a href="clear_notif.php?event_id=<?php echo $latest_id; ?>" class="btn-ok" style="text-decoration:none;">Maybe Later</a>
            <a href="event_details.php?id=<?php echo $latest_id; ?>" class="btn-ok" style="text-decoration:none; background: #2ecc71;">View Now</a>
        </div>
    </div>
</div>
<?php endif; ?>

</body>
</html>

