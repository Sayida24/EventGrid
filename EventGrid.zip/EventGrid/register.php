<?php
include 'includes/db.php';

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['fullname']);
    $uni_id = mysqli_real_escape_string($conn, $_POST['university_id']); // Can be Student or Admin ID
    $dept = isset($_POST['department']) ? mysqli_real_escape_string($conn, $_POST['department']) : 'Administration';
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' OR university_id='$uni_id'");
    
    if(mysqli_num_rows($check) > 0) {
        $error = "This University ID or Email is already registered!";
    } else {
        $sql = "INSERT INTO users (fullname, university_id, department, email, password, role) 
                VALUES ('$name', '$uni_id', '$dept', '$email', '$password', '$role')";
        
        if (mysqli_query($conn, $sql)) {
            header("Location: index.php?success=Account Created Successfully");
            exit();
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>University Registration | EventGrid</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script>
        // JavaScript to change labels based on role
        function toggleRole() {
            var role = document.getElementById("roleSelect").value;
            var idInput = document.getElementById("idInput");
            var deptSection = document.getElementById("deptSection");

            if (role === "admin") {
                idInput.placeholder = "Admin / Staff ID";
                deptSection.style.display = "none"; // Admins don't always need a specific academic dept
            } else {
                idInput.placeholder = "Student ID (e.g. 2024-001)";
                deptSection.style.display = "block";
            }
        }
    </script>
</head>
<body class="auth-page">
    <div class="login-container">
        <div class="login-box">
            <h2>Registration</h2>
            <p>Please use your official university credentials</p>

            <?php if(isset($error)) { echo "<p class='error'>$error</p>"; } ?>

            <form action="register.php" method="POST">
                
                <!-- Role Selection First -->
                <select name="role" id="roleSelect" onchange="toggleRole()" required>
                    <option value="student">I am a Student</option>
                    <option value="admin">I am an Administrator</option>
                </select>

                <input type="text" name="fullname" placeholder="Full Name" required>
                
                <input type="text" name="university_id" id="idInput" placeholder="Student ID " required>
                
                <div id="deptSection">
                    <select name="department">
                        <option value="" disabled selected>Select Department</option>
                        <option value="Computer Science">Computer Science & Engineering</option>
                        <option value="Engineering"> Software Engineering</option>
                        <option value="Business Admin">Nutration and Food Engineering</option>
                        <option value="Arts & Humanities">Microbiology</option>
                    </select>
                </div>

                <input type="email" name="email" placeholder="University Email (@diu.edu.bd)" required>
                
                <input type="password" name="password" placeholder="Create Password" required>
                
                <button type="submit" name="register" class="btn-login">Create Account</button>
            </form>

            <div class="login-footer">
                <p>Already registered? <a href="index.php">Login here</a></p>
            </div>
        </div>
    </div>
</body>
</html>