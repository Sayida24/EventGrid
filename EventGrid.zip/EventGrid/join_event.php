<?php
/** @var mysqli $conn */
require_once 'includes/db.php';

// 1. Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$event_id = mysqli_real_escape_string($conn, $_GET['event_id']);

// 2. Check if already registered to prevent duplicates
$check = mysqli_query($conn, "SELECT id FROM registrations WHERE user_id = '$user_id' AND event_id = '$event_id'");

if (mysqli_num_rows($check) > 0) {
    echo "<script>alert('You are already registered for this event!'); window.location.href='dashboard.php';</script>";
} else {
    // 3. Generate the Mandatory Food Coupon (Requirement 5)
    $coupon_code = "GRID-" . rand(1000, 9999) . "-" . substr($_SESSION['name'], 0, 2);

    // 4. Insert into database
    $sql = "INSERT INTO registrations (user_id, event_id, food_coupon) VALUES ('$user_id', '$event_id', '$coupon_code')";
    
    if (mysqli_query($conn, $sql)) {
        // Success: Show the coupon in an alert
        echo "<script>
                alert('Registration Successful! Your Food Coupon is: $coupon_code'); 
                window.location.href='my_registrations.php';
              </script>";
    } else {
        // This will tell us EXACTLY why it failed
        echo "Database Error: " . mysqli_error($conn);
    }
}
?>