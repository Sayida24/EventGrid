</div> <!-- End of container -->
    <footer>
        <p>&copy; <?php echo date('Y'); ?> EventGrid -Platform</p>
    </footer>
    <script src="assets/js/script.js"></script>
</body>
</html>