<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

// Check if a user is logged in to decide whether to show the sidebar
$is_logged_in = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us | EventGrid Team</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Special styles for the Team section */
        .team-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }
        .team-card {
            background: #f8fafc;
            padding: 30px 20px;
            border-radius: 15px;
            text-align: center;
            border: 1px solid #e2e8f0;
            transition: 0.3s;
        }
        .team-card:hover {
            transform: translateY(-5px);
            border-color: #3182ce;
            box-shadow: 0 10px 20px rgba(0,0,0,0.05);
        }
        .member-icon {
            width: 70px;
            height: 70px;
            background: #3182ce;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin: 0 auto 15px;
            font-weight: bold;
        }
        .member-name {
            font-size: 1.2rem;
            font-weight: bold;
            color: #2d3748;
            margin-bottom: 5px;
        }
        .member-dept {
            font-size: 0.85rem;
            color: #718096;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
    </style>
</head>
<body class="admin-body">

<div class="admin-wrapper">
    
    <!-- SIDEBAR (Only shows if logged in) -->
    <?php if($is_logged_in): ?>
    <div class="admin-sidebar">
        <div class="admin-sidebar-header"><h2>EventGrid</h2></div>
        <nav class="admin-nav">
            <a href="dashboard.php">🏠 Explore Events</a>
            <a href="my_registrations.php">📅 My Registrations</a>
            <a href="about_us.php" class="active">ℹ️ About Us</a>
            <a href="logout.php">Logout</a>
        </nav>
    </div>
    <?php endif; ?>

    <!-- MAIN CONTENT -->
    <main class="admin-main" style="<?php echo !$is_logged_in ? 'margin-left: 0; width: 100%;' : ''; ?>">
        
        <?php if(!$is_logged_in): ?>
            <div style="margin-bottom: 20px; max-width: 1000px; margin: 0 auto 20px;">
                <a href="index.php" style="text-decoration: none; color: #3182ce; font-weight: bold;">← Back to Login</a>
            </div>
        <?php endif; ?>

        <div class="form-card" style="max-width: 1000px; margin: 0 auto; padding: 50px;">
            
            <!-- PROJECT INFO -->
            <div style="text-align: center; margin-bottom: 50px;">
                <h1 style="font-size: 2.5rem; color: #2d3748;">EventGrid</h1>
                <p style="color: #718096; font-size: 1.1rem; max-width: 700px; margin: 15px auto;">
                    A comprehensive Smart University Event Management Platform developed to streamline campus activities, startup markets and volunteer coordination.
                </p>
            </div>

            <hr style="border: 0; border-top: 1px solid #edf2f7; margin-bottom: 50px;">

            <!-- THE DEVELOPERS -->
            <h2 style="text-align: center; color: #2d3748; margin-bottom: 10px;">The Development Team</h2>
            <p style="text-align: center; color: #a0aec0; margin-bottom: 40px;">Students of the Department of Software Engineering</p>

            <div class="team-section">
                <!-- Member 1 -->
                <div class="team-card">
                    <div class="member-icon">M</div>
                    <div class="member-name">Mst Sayida Parvin</div>
                    <!-- <div class="member-dept">Software Engineering</div> -->
                </div>

                <!-- Member 2 -->
                <div class="team-card">
                    <div class="member-icon">A</div>
                    <div class="member-name">Afifa Rahman</div>
                    <!-- <div class="member-dept">Software Engineering</div> -->
                </div>

                <!-- Member 3 -->
                <div class="team-card">
                    <div class="member-icon">P</div>
                    <div class="member-name">Payel Saha</div>
                    <!-- <div class="member-dept">Software Engineering</div> -->
                </div>
            </div>

            <!-- ACADEMIC CONTEXT -->
            <div style="margin-top: 60px; background: #ebf8ff; padding: 30px; border-radius: 15px; border-left: 5px solid #3182ce;">
                <h3 style="color: #2c5282; margin-bottom: 10px;">Academic Project Scope</h3>
                <p style="color: #2d3748; line-height: 1.7;">
                    <!-- This project was developed as a part of the academic curriculum to demonstrate full-stack web development skills using **PHP, MySQL,CSS**. EventGrid addresses real-world university challenges by providing automated food coupon generation, selection-based startup stall booking, and volunteer management. -->
              This project was developed as a part of the academic curriculum to demonstrate full-stack web development skills using **PHP, MySQL, CSS**.
                </p>
            </div>

        </div>
    </main>
</div>

</body>
</html>