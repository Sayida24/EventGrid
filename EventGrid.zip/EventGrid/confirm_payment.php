<?php
/** @var mysqli $conn */
require_once 'includes/db.php';

if(isset($_POST['confirm_pay'])) {
    $app_id = mysqli_real_escape_string($conn, $_POST['app_id']);
    $trx = mysqli_real_escape_string($conn, $_POST['trx_id']);

    // 1. Get the details of this application first
    $app_query = mysqli_query($conn, "SELECT user_id, event_id FROM stall_applications WHERE id = '$app_id'");
    $app_data = mysqli_fetch_assoc($app_query);
    
    $uid = $app_data['user_id'];
    $eid = $app_data['event_id'];

    // 2. Update the Stall Application to PAID
    $update_stall = "UPDATE stall_applications SET payment_status = 'paid', trx_id = '$trx' WHERE id = '$app_id'";
    
    if(mysqli_query($conn, $update_stall)) {
        
        // 3. IMPORTANT: Insert the student into the main registrations table 
        // so they appear in the Admin's "View List"
        $reg_sql = "INSERT INTO registrations (user_id, event_id, reg_type, food_coupon) 
                    VALUES ('$uid', '$eid', 'Stall Holder', 'STALL-PAY')";
        
        mysqli_query($conn, $reg_sql);

        header("Location: dashboard.php?msg=Payment Verified! You are now on the official list.");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>