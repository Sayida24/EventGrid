
<?php
/** @var mysqli $conn */
require_once 'includes/db.php';

if(isset($_POST['submit_stall'])) {
    $uid = $_SESSION['user_id'];
    $eid = $_POST['event_id'];
    $pname = mysqli_real_escape_string($conn, $_POST['page_name']);
    $flink = mysqli_real_escape_string($conn, $_POST['fb_link']);
    $pdet = mysqli_real_escape_string($conn, $_POST['product_details']);
    $psource = mysqli_real_escape_string($conn, $_POST['purchase_place']);

    // We explicitly set status to 'pending'
    $sql = "INSERT INTO stall_applications (event_id, user_id, page_name, fb_link, product_details, purchase_place, status) 
            VALUES ('$eid', '$uid', '$pname', '$flink', '$pdet', '$psource', 'pending')";
    
    if(mysqli_query($conn, $sql)) {
        header("Location: dashboard.php?msg=Application submitted successfully!");
        exit();
    } else {
        die("Database Error: " . mysqli_error($conn));
    }
}
?>