<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

// 1. Security Check: Only logged-in students can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: index.php");
    exit();
}

// 2. Handle New Suggestion Submission
if (isset($_POST['post_suggestion'])) {
    $msg = mysqli_real_escape_string($conn, $_POST['msg']);
    $uid = $_SESSION['user_id'];
    
    // Insert into database
    $sql = "INSERT INTO feedback (user_id, comment) VALUES ('$uid', '$msg')";
    
    if (mysqli_query($conn, $sql)) {
        // Redirect to avoid form resubmission on page refresh
        header("Location: feedback.php?success=1");
        exit();
    }
}

// 3. Fetch all suggestions with Student Name and Department
$query = "SELECT feedback.*, users.fullname, users.department 
          FROM feedback 
          JOIN users ON feedback.user_id = users.id 
          ORDER BY feedback.id DESC";
$all_suggestions = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Forum | EventGrid</title>
    <!-- Link to your CSS file -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- STUDENT SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2>EventGrid</h2>
            <p>Student Portal</p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php">Explore Events</a>
            <a href="my_registrations.php">My Registrations</a>
             <a href="my_stalls.php">🛒 Stall Status</a>
            <a href="notification.php">Notifications</a>
            <a href="feedback.php" class="active">Suggestions</a>
           
            <a href="logout.php">Logout</a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="forum-container">
            
            <div class="page-header">
                <h1>Campus Suggestions Forum</h1>
                <p>Have an idea for a new event? Share it with the community and the administration.</p>
            </div>

            <!-- INPUT CARD (THE FIELDSET REPLACEMENT) -->
            <div class="suggestion-input-card">
                <h3>Post a New Suggestion</h3>
                <form action="feedback.php" method="POST">
                    <textarea name="msg" placeholder="e.g. The Genetic Engineering department would love a seminar on CRISPR technology..." required></textarea>
                    
                    <div class="button-container">
                        <button type="submit" name="post_suggestion" class="btn-publish" style="width: auto; padding: 12px 40px;">
                            Post to Forum
                        </button>
                    </div>
                </form>
            </div>

            <hr style="margin-bottom: 40px; border: 0; border-top: 1px solid #e2e8f0;">

            <!-- FORUM FEED -->
            <div class="forum-feed">
                <?php if (mysqli_num_rows($all_suggestions) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($all_suggestions)): 
                        // Generate the Initial for the Avatar
                        $initial = strtoupper(substr($row['fullname'], 0, 1));
                    ?>
                        
                        <!-- Individual Forum Post Card -->
                        <div class="forum-card">
                            <!-- Avatar Circle -->
                            <div class="user-avatar">
                                <?php echo $initial; ?>
                            </div>

                            <!-- Message Content -->
                            <div class="forum-body">
                                <div class="forum-header">
                                    <span class="student-name"><?php echo $row['fullname']; ?></span>
                                    <span class="dept-label"><?php echo $row['department']; ?></span>
                                </div>
                                <p class="forum-text">
                                    <?php echo nl2br(htmlspecialchars($row['comment'])); ?>
                                </p>
                            </div>
                        </div>

                    <?php endwhile; ?>
                <?php else: ?>
                    <!-- Empty State if no suggestions exist -->
                    <div style="text-align: center; padding: 50px; color: #a0aec0;">
                        <p>No suggestions have been posted yet. Be the first to start the conversation!</p>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </main>
</div>

</body>
</html>