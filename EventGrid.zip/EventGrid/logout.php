<?php
// 1. Start the session so we can access it
session_start();

// 2. Unset all session variables (name, role, user_id, etc.)
session_unset();

// 3. Destroy the session entirely
session_destroy();

// 4. Redirect the user back to the homepage (index.php)
header("Location: index.php");
exit();
?>