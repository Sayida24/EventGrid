<?php
/** @var mysqli $conn */
require_once 'includes/db.php';

// 1. Check if the user is logged in and the event_id is sent
if (isset($_GET['event_id']) && isset($_SESSION['user_id'])) {
    
    $event_id = mysqli_real_escape_string($conn, $_GET['event_id']);
    $user_id = $_SESSION['user_id'];

    // 2. Update the user table to record that they have seen this event
    $sql = "UPDATE users SET last_seen_event_id = '$event_id' WHERE id = '$user_id'";
    
    if (mysqli_query($conn, $sql)) {
        // 3. Successfully updated, send them back to the dashboard
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Database Error: " . mysqli_error($conn);
    }
} else {
    // If someone tries to access this file directly without an ID, just send them home
    header("Location: dashboard.php");
    exit();
}
?>