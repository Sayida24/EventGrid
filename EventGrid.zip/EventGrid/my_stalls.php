<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: index.php"); exit();
}

$user_id = $_SESSION['user_id'];

// Fetch Stall Applications for this student
$stall_query = "SELECT stall_applications.*, events.title as event_name, events.poster 
                FROM stall_applications 
                JOIN events ON stall_applications.event_id = events.id 
                WHERE stall_applications.user_id = '$user_id'
                ORDER BY stall_applications.created_at DESC";
$my_stalls = mysqli_query($conn, $stall_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Stall Status | EventGrid</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- STUDENT SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header"><h2>EventGrid</h2><p>Student Portal</p></div>
        <nav class="admin-nav">
            <a href="dashboard.php">🏠 Explore Events</a>
            <a href="my_registrations.php">📅 My Registrations</a>
            <!-- NEW SIDEBAR OPTION -->
            <a href="my_stalls.php" class="active">🛒 Stall Status</a>
            <a href="notification.php">🔔 Notifications</a>
            <a href="feedback.php">💬 Suggestions</a>
            <a href="logout.php">🚪 Logout</a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="page-header">
            <h1>My Startup Stalls</h1>
            <p>Track your applications and complete payments for approved stalls.</p>
        </div>

        <div class="student-event-grid">
            <?php if(mysqli_num_rows($my_stalls) > 0): ?>
                <?php while($stall = mysqli_fetch_assoc($my_stalls)): ?>
                    
                    <div class="student-event-card" style="border-top: 5px solid #f6ad55;">
                        <div class="card-img-container" style="height: 120px;">
                            <img src="uploads/<?php echo $stall['poster']; ?>" alt="Event">
                        </div>
                        <div class="card-text-content">
                            <h3 style="margin-bottom: 5px;"><?php echo $stall['event_name']; ?></h3>
                            <p style="font-size: 0.9rem; margin-bottom: 15px;">
                                Status: 
                                <strong style="color: <?php echo ($stall['status'] == 'approved') ? '#38a169' : (($stall['status'] == 'rejected') ? '#e53e3e' : '#f6ad55'); ?>;">
                                    <?php echo strtoupper($stall['status']); ?>
                                </strong>
                            </p>

                            <?php if($stall['status'] == 'approved' && $stall['payment_status'] == 'unpaid'): ?>
                                <a href="payment.php?app_id=<?php echo $stall['id']; ?>" class="btn-publish" style="background: #38a169; text-decoration: none; padding: 10px; font-size: 0.85rem; display: block; text-align: center;">
                                    Pay 500 BDT & Confirm
                                </a>
                            <?php elseif($stall['payment_status'] == 'paid'): ?>
                                <div style="background: #f0fff4; color: #38a169; padding: 10px; border-radius: 8px; text-align: center; font-weight: bold; font-size: 0.85rem;">
                                    ✅ Paid & Confirmed
                                </div>
                            <?php elseif($stall['status'] == 'rejected'): ?>
                                <p style="color: #e53e3e; font-size: 0.8rem;">Application was not selected.</p>
                            <?php else: ?>
                                <p style="color: #718096; font-size: 0.8rem; font-style: italic;">Awaiting Admin Review...</p>
                            <?php endif; ?>
                        </div>
                    </div>

                <?php endwhile; ?>
            <?php else: ?>
                <div style="grid-column: span 2; text-align: center; padding: 50px; background: white; border-radius: 15px;">
                    <p>You haven't applied for any Startup Stalls yet.</p>
                    <a href="dashboard.php" style="color: #3182ce; text-decoration: none; font-weight: bold;">Browse Events →</a>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

</body>
</html>