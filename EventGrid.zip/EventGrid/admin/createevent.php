<?php 
/** @var mysqli $conn */
require_once '../includes/db.php'; 

// 1. Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$success = "";
$error = "";

// 2. Handle Form Submission
if(isset($_POST['save_event'])){
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $type = $_POST['event_type'];
    $date = $_POST['date'];
    $venue = mysqli_real_escape_string($conn, $_POST['venue']);
    $food = isset($_POST['food_coupon']) ? 1 : 0;
    
    // NEW PROPERTIES: Volunteers
    $v_needed = isset($_POST['volunteers_needed']) ? 1 : 0;
    $v_limit = mysqli_real_escape_string($conn, $_POST['volunteer_limit']);
    
    $parts = isset($_POST['participants']) ? implode(", ", $_POST['participants']) : "Students";

    // Handle Image Upload
    $posterName = time() . "_" . $_FILES['poster']['name'];
    $targetPath = "../uploads/" . $posterName;

    if(move_uploaded_file($_FILES['poster']['tmp_name'], $targetPath)){
        
        // 3. Updated SQL query to include volunteers_needed and volunteer_limit
        $sql = "INSERT INTO events (title, event_type, event_date, location, poster, participant_types, food_coupon, volunteers_needed, volunteer_limit) 
                VALUES ('$title', '$type', '$date', '$venue', '$posterName', '$parts', '$food', '$v_needed', '$v_limit')";
        
        if(mysqli_query($conn, $sql)){
            
            // ============================================================
            // 4. NEW CHANGE: Create Notification with the Link (event_id)
            // ============================================================
            $new_event_id = mysqli_insert_id($conn); // This catches the ID of the event just saved
            $notif_msg = "New Event Added: " . $title;
            
            // We now insert the $new_event_id into the notifications table
            mysqli_query($conn, "INSERT INTO notifications (message, event_id) VALUES ('$notif_msg', '$new_event_id')");
            
            $success = "Event successfully posted and clickable notification sent!";
        } else {
            $error = "Database Error: " . mysqli_error($conn);
        }
    } else {
        $error = "Failed to upload the poster image.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Event | Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2>EventGrid</h2>
        </div>
       <nav class="admin-nav">
    <a href="dashboard.php">Dashboard</a>
    <a href="createevent.php">Create Event</a>
    <a href="manageevent.php">Manage Events</a>
    <a href="manage_volunteers.php">Volunteer Requests</a>
    <!-- ADD THIS NEW LINE BELOW -->
    <a href="view_feedback.php">Review Feedback</a> 
    <!-- <hr style="border: 0.5px solid #2d3748; margin: 10px 0;"> -->
      <a href="manage_stalls.php">Stall Requests</a>
    <a href="../logout.php">Logout</a>
</nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="page-header">
            <h1>Create University Event</h1>
        </div>

        <div class="form-card">
            <?php if($success) echo "<p style='color:green; margin-bottom:15px; font-weight:bold;'>$success</p>"; ?>
            <?php if($error) echo "<p style='color:red; margin-bottom:15px; font-weight:bold;'>$error</p>"; ?>

            <form action="createevent.php" method="POST" enctype="multipart/form-data">
                
                <div class="form-group">
                    <label>Event Title</label>
                    <input type="text" name="title" placeholder="e.g., Spring Tech Fest 2024" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Event Category</label>
                        <select name="event_type">
                            <option value="Seminar">Seminar</option>
                            <option value="Startup Market">Startup Market</option>
                            <option value="Cultural">Cultural</option>
                            <option value="Concert">Concert</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Poster Image</label>
                        <input type="file" name="poster" accept="image/*" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Date</label>
                        <input type="date" name="date" required>
                    </div>
                    <div class="form-group">
                        <label>Venue / Location</label>
                        <input type="text" name="venue" placeholder="e.g., Auditorium Hall B" required>
                    </div>
                </div>

                <!-- VOLUNTEER PROPERTY SECTION -->
                <div class="form-row" style="background: #f7fafc; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px dashed #cbd5e0;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                            <input type="checkbox" name="volunteers_needed" value="1"> 
                            <strong>Need Volunteers for this event?</strong>
                        </label>
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label>Volunteer Limit (Maximum students)</label>
                        <input type="number" name="volunteer_limit" value="0" min="0">
                    </div>
                </div>

                <div class="form-group">
                    <label>Target Audience</label>
                    <div style="background:#f7fafc; padding:15px; border-radius:8px;">
                        <input type="checkbox" name="participants[]" value="Student" checked> Students &nbsp;&nbsp;
                        <input type="checkbox" name="participants[]" value="Faculty"> Faculty &nbsp;&nbsp;
                        <input type="checkbox" name="participants[]" value="Guest"> Guests
                    </div>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="food_coupon"> Provide Food Coupon?
                    </label>
                </div>

                <button type="submit" name="save_event" class="btn-publish">Publish Event</button>
            </form>
        </div>
    </main>
</div>

</body>
</html>