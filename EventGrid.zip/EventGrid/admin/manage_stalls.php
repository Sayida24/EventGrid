<?php 
/** @var mysqli $conn */
require_once '../includes/db.php'; 

// Fetch applications where status is 'pending'
$query = "SELECT stall_applications.*, users.fullname, events.title 
          FROM stall_applications 
          INNER JOIN users ON stall_applications.user_id = users.id 
          INNER JOIN events ON stall_applications.event_id = events.id 
          WHERE stall_applications.status = 'pending'";

$requests = mysqli_query($conn, $query);

if (!$requests) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stall Approvals | EventGrid Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2>EventGrid</h2>
            <p style="color: #a0aec0; font-size: 0.8rem;">Admin Panel</p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="createevent.php">Create Event</a>
            <a href="manageevent.php">Manage Events</a>
            <a href="manage_volunteers.php">Volunteer Requests</a>
            <a href="manage_stalls.php" class="active">Stall Requests</a>
            <a href="view_feedback.php">Review Feedback</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="page-header">
            <h1>Stall Booking Requests</h1>
            <p>Review student business proposals and approve them for the Startup Market.</p>
        </div>

        <!-- Success Message -->
        <?php if(isset($_GET['msg'])): ?>
            <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 5px solid #28a745;">
                ✅ <?php echo htmlspecialchars($_GET['msg']); ?>
            </div>
        <?php endif; ?>

        <div class="form-card" style="max-width: 100%;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Student Info</th>
                        <th>Business Details</th>
                        <th>Product & Sourcing</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($requests) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($requests)): ?>
                            <tr>
                                <!-- Student Info -->
                                <td>
                                    <strong><?php echo $row['fullname']; ?></strong><br>
                                    <small style="color: gray;"><?php echo $row['university_id']; ?></small><br>
                                    <small>Event: <em><?php echo $row['title']; ?></em></small>
                                </td>

                                <!-- Business Details -->
                                <td>
                                    <strong><?php echo $row['page_name']; ?></strong><br>
                                    <a href="<?php echo $row['fb_link']; ?>" target="_blank" style="color: #3182ce; font-size: 0.85rem;">View FB Page ↗</a>
                                </td>

                                <!-- Product Info -->
                                <td style="max-width: 300px;">
                                    <p style="font-size: 0.9rem; margin-bottom: 5px;"><strong>Products:</strong> <?php echo $row['product_details']; ?></p>
                                    <p style="font-size: 0.85rem; color: #718096;"><strong>Source:</strong> <?php echo $row['purchase_place']; ?></p>
                                </td>

                                <!-- Approval Buttons -->
                                <td>
                                    <div style="display: flex; flex-direction: column; gap: 8px;">
                                        <a href="process_stall_logic.php?id=<?php echo $row['id']; ?>&status=approved&uid=<?php echo $row['user_id']; ?>&eid=<?php echo $row['event_id']; ?>" 
                                           style="background: #38a169; color: white; text-align: center; padding: 8px; border-radius: 5px; text-decoration: none; font-size: 0.85rem; font-weight: bold;">
                                           Approve
                                        </a>
                                        
                                        <a href="process_stall_logic.php?id=<?php echo $row['id']; ?>&status=rejected&uid=<?php echo $row['user_id']; ?>&eid=<?php echo $row['event_id']; ?>" 
                                           onclick="return confirm('Reject this application?')"
                                           style="background: #e53e3e; color: white; text-align: center; padding: 8px; border-radius: 5px; text-decoration: none; font-size: 0.85rem; font-weight: bold;">
                                           Reject
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 50px; color: #a0aec0;">
                                No pending stall applications at this time.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

</body>
</html>