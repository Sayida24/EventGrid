<?php 
/** @var mysqli $conn */ // This line fixes the VS Code red line "mistake"
require_once '../includes/db.php'; 

// 1. Security check: Ensure Admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Unauthorized access.");
}

// 2. Capture and Clean the data from the URL
// We check if the ID exists first to prevent "Undefined Index" errors
if (isset($_GET['id'], $_GET['status'], $_GET['uid'], $_GET['eid'])) {
    
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $status = mysqli_real_escape_string($conn, $_GET['status']);
    $user_id = mysqli_real_escape_string($conn, $_GET['uid']);
    $event_id = mysqli_real_escape_string($conn, $_GET['eid']);

    // 3. Update the Stall Application Status
    $update_query = "UPDATE stall_applications SET status = '$status' WHERE id = '$id'";
    
    if (mysqli_query($conn, $update_query)) {
        
        // 4. Prepare the Notification Message
        if ($status == 'approved') {
            $msg = "Congratulations! Your Startup Stall has been SELECTED. Please proceed to payment to confirm your booking.";
        } else {
            $msg = "We regret to inform you that your stall application for this event was not selected.";
        }

        // 5. Insert the notification into the user_notifications table
        // This ensures the student sees the result on their dashboard
        $notif_sql = "INSERT INTO user_notifications (user_id, message, event_id) 
                      VALUES ('$user_id', '$msg', '$event_id')";
        
        mysqli_query($conn, $notif_sql);

        // 6. Redirect back with a success message
        header("Location: manage_stalls.php?msg=Application " . ucfirst($status));
        exit();
        
    } else {
        echo "Database Error: " . mysqli_error($conn);
    }
} else {
    // If someone tries to open the file without proper data, send them back
    header("Location: manage_stalls.php");
    exit();
}