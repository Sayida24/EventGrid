<?php 
/** @var mysqli $conn */
require_once __DIR__ . '/../includes/db.php'; 

// Check if user is admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Use $conn
$user_query = "SELECT id FROM users WHERE role='student'";
$user_result = mysqli_query($conn, $user_query);
$students = mysqli_num_rows($user_result);

$event_query = "SELECT id FROM events";
$event_result = mysqli_query($conn, $event_query);
$events = mysqli_num_rows($event_result);

$reg_query = "SELECT id FROM registrations";
$reg_result = mysqli_query($conn, $reg_query);
$regs = mysqli_num_rows($reg_result);

// 1. Suggestions Logic
$sugg_count = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM feedback"));

// 2. Stall Requests Logic: Count only PENDING
$stall_request_count = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM stall_applications WHERE status = 'pending'"));

// 3. NEW LOGIC: Count only PENDING Volunteer Applications
$vol_request_count = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM volunteer_apps WHERE status = 'pending'"));

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard | EventGrid</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2>EventGrid</h2>
            <p style="color: #a0aec0; font-size: 0.8rem;">Admin: <?php echo $_SESSION['name']; ?></p>
        </div>
        
        <nav class="admin-nav">
            <a href="dashboard.php" class="active">Dashboard</a>
            <a href="createevent.php">Create Event</a>
            <a href="manageevent.php">Manage Events</a>
            <a href="manage_volunteers.php">Volunteer Requests</a>
            <a href="view_feedback.php">Review Feedback</a> 
            <a href="manage_stalls.php">Stall Requests</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="page-header">
            <h1>Welcome, <?php echo $_SESSION['name']; ?></h1>
            <!-- <p>Here is what's happening at the university today.</p> -->
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Events</h3>
                <p><?php echo $events; ?></p>
                <h3>Registrations</h3>
                <p><?php echo $regs; ?></p>
                
            </div>
            
            
            <div class="stat-card" style="border-top: 4px solid #e53e3e;">
                <h3>Suggestions</h3>
                <p><?php echo $sugg_count; ?></p>
                <a href="view_feedback.php" style="font-size: 0.8rem; color: #3182ce; text-decoration: none;">Review Feedback →</a>
            <!-- </div>

            <div class="stat-card" style="border-top: 4px solid #f6ad55;"> -->
                <h3>Stall Requests</h3>
                <p><?php echo $stall_request_count; ?></p>
                <a href="manage_stalls.php" style="font-size: 0.8rem; color: #3182ce; text-decoration: none;">Check Proposals →</a>
            <!-- </div> -->

            <!-- NEW STAT CARD FOR VOLUNTEER REQUESTS -->
            <!-- <div class="stat-card" style="border-top: 4px solid #38a169;"> -->
                <h3>Volunteer Requests</h3>
                <p><?php echo $vol_request_count; ?></p>
                <a href="manage_volunteers.php" style="font-size: 0.8rem; color: #3182ce; text-decoration: none;">Review Applicants →</a>
            </div><br>
<div class="stat-card" style="border-top: 4px solid #38a169;"></div>
        </div>
    </main>
</div>

</body>
</html>