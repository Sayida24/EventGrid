<?php 
/** @var mysqli $conn */
require_once '../includes/db.php'; 

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$query = "SELECT * FROM events ORDER BY event_date DESC";
$events = mysqli_query($conn, $query);

if (!$events) {
    die("Database Error: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Events | EventGrid Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2>EventGrid</h2>
            <p style="color: #a0aec0; font-size: 0.8rem;">Admin: <?php echo $_SESSION['name']; ?></p>
        </div>
        <nav class="admin-nav">
    <a href="dashboard.php">Dashboard</a>
    <a href="createevent.php">Create Event</a>
    <a href="manageevent.php">Manage Events</a>
    <a href="manage_volunteers.php">Volunteer Requests</a>
    <!-- ADD THIS NEW LINE BELOW -->
    <a href="view_feedback.php">Review Feedback</a> 
    <!-- <hr style="border: 0.5px solid #2d3748; margin: 10px 0;"> -->
      <a href="manage_stalls.php">Stall Requests</a>
    <a href="../logout.php">Logout</a>
</nav>
    </div>

    <main class="admin-main">
        <div class="page-header">
            <h1>Manage University Events</h1>
            <p>View registrations or remove upcoming campus activities.</p>
        </div>

        <?php if(isset($_GET['msg'])): ?>
            <div style="background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
                ✅ <?php echo htmlspecialchars($_GET['msg']); ?>
            </div>
        <?php endif; ?>

        <div class="form-card" style="max-width: 100%;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Poster</th>
                        <th>Event Title</th>
                        <th>Type</th>
                        <th>Date</th>
                        <th>Venue</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($events) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($events)): ?>
                            <tr>
                                <td>
                                    <img src="../uploads/<?php echo $row['poster']; ?>" alt="Poster" class="table-img">
                                </td>
                                <td style="font-weight: 600; color: #2d3748;"><?php echo $row['title']; ?></td>
                                <td><span class="badge"><?php echo $row['event_type']; ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($row['event_date'])); ?></td>
                                <td><?php echo $row['location']; ?></td>
                                <td>
                                    <div style="display: flex; gap: 15px; align-items: center;">
                                        <!-- NEW: View Registrations Link -->
                                        <a href="view_participants.php?id=<?php echo $row['id']; ?>" 
                                           style="color: #3182ce; text-decoration: none; font-weight: bold; font-size: 0.9rem;">
                                           View List
                                        </a>

                                        <!-- Delete Link -->
                                        <a href="delete_event.php?id=<?php echo $row['id']; ?>" 
                                           onclick="return confirm('WARNING: Deleting this event will also remove all student registrations and volunteer applications associated with it. Continue?')" 
                                           class="delete-btn">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 40px;">No events found. <a href="createevent.php">Create one now.</a></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

</body>
</html>