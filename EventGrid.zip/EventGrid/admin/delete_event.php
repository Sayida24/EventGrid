<?php 
/** @var mysqli $conn */
require_once '../includes/db.php'; 

// 1. Security Check: Only admins can delete
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// 2. Check if the ID is provided
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // 3. IMPORTANT: Delete dependencies first 
    // (Delete registrations and volunteer apps tied to this event so MySQL doesn't give an error)
    mysqli_query($conn, "DELETE FROM registrations WHERE event_id = '$id'");
    mysqli_query($conn, "DELETE FROM volunteer_apps WHERE event_id = '$id'");
    mysqli_query($conn, "DELETE FROM stall_applications WHERE event_id = '$id'");

    // 4. Delete the actual event
    $sql = "DELETE FROM events WHERE id = '$id'";
    
    if (mysqli_query($conn, $sql)) {
        // Success: Go back to the list
        header("Location: manageevent.php?msg=Event Deleted Successfully");
    } else {
        // Error
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    header("Location: manageevent.php");
}
?>