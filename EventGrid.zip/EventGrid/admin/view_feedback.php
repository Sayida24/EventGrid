<?php 
/** @var mysqli $conn */
require_once '../includes/db.php'; 

// 1. Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// 2. Fetch all feedback/suggestions with student details
$query = "SELECT feedback.*, users.fullname, users.university_id, users.department 
          FROM feedback 
          JOIN users ON feedback.user_id = users.id 
          ORDER BY feedback.id DESC";
$results = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Review Feedback | Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2>EventGrid</h2>
            <p style="color: #a0aec0; font-size: 0.8rem;">Admin Panel</p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="createevent.php">Create Event</a>
            <a href="manageevent.php">Manage Events</a>
            <a href="manage_volunteers.php">Volunteer Requests</a>
            <a href="view_feedback.php" class="active">Review Feedback</a>
              <a href="manage_stalls.php">Stall Requests</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="page-header">
            <h1>Student Suggestions & Feedback</h1>
            <p>Review current student requests and ideas for university events.</p>
        </div>

        <div class="form-card" style="max-width: 100%;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>University ID</th>
                        <th>Department</th>
                        <th>Suggestion / Comment</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($results) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($results)): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($row['fullname']); ?></strong></td>
                                <td><?php echo htmlspecialchars($row['university_id']); ?></td>
                                <td><span class="badge"><?php echo htmlspecialchars($row['department']); ?></span></td>
                                <td style="max-width: 500px; line-height: 1.6; color: #4a5568; padding: 15px;">
                                    <?php echo nl2br(htmlspecialchars($row['comment'])); ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <!-- Colspan is now 4 because we removed the Action column -->
                            <td colspan="4" style="text-align: center; padding: 50px; color: gray;">
                                No suggestions have been posted yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

</body>
</html>