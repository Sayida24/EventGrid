<?php 
require_once '../includes/db.php'; 
/** @var mysqli $conn */

// This is the full JOIN query that was cut off in your message
$sql = "SELECT stall_applications.*, users.fullname 
        FROM stall_applications 
        JOIN users ON stall_applications.user_id = users.id";

$res = mysqli_query($conn, $sql);

if(!$res) { die("Query Error: " . mysqli_error($conn)); }
?>
<div class="admin-wrapper">
    <main class="admin-main">
        <h1>Startup Stall Requests</h1>
        <table class="admin-table">
            <tr>
                <th>Student</th><th>FB Page</th><th>Products</th><th>Status</th><th>Action</th>
            </tr>
            <?php
            $res = mysqli_query($conn, "SELECT stall_applications.*, users.fullname FROM stall_applications JOIN users ON stall_applications.user_id = users.id");
            while($row = mysqli_fetch_assoc($res)) {
                echo "<tr>
                    <td>{$row['fullname']}</td>
                    <td><a href='{$row['fb_page']}'>Visit Page</a></td>
                    <td>{$row['products']}</td>
                    <td>{$row['admin_approval']}</td>
                    <td>
                        <a href='approve_logic.php?id={$row['id']}&action=approved'>Approve</a> | 
                        <a href='approve_logic.php?id={$row['id']}&action=rejected'>Reject</a>
                    </td>
                </tr>";
            }
            ?>
        </table>
    </main>
</div>