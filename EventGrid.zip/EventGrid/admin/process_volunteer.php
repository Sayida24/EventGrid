<?php 
/** @var mysqli $conn */
require_once '../includes/db.php'; 

// 1. Get data from URL
$app_id = $_GET['id'];
$status = $_GET['status'];
$user_id = $_GET['uid'];
$event_name = urldecode($_GET['ename']);
$event_id = $_GET['eid'];

// 2. Update Application Table
$update_sql = "UPDATE volunteer_apps SET status = '$status' WHERE id = '$app_id'";

if(mysqli_query($conn, $update_sql)) {
    // 3. Create a Private Notification for the Student
    if($status == 'approved') {
        $msg = "Congratulations! You are approved as a volunteer for: " . $event_name;
    } else {
        $msg = "Sorry, your volunteer application for " . $event_name . " was rejected.";
    }

    // Insert into user_notifications table so student sees it
    $notif_sql = "INSERT INTO user_notifications (user_id, message, event_id) VALUES ('$user_id', '$msg', '$event_id')";
    mysqli_query($conn, $notif_sql);

    header("Location: manage_volunteers.php?msg=Student $status successfully");
} else {
    echo "Error: " . mysqli_error($conn);
}