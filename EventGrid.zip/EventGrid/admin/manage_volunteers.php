<?php 
/** @var mysqli $conn */
require_once '../includes/db.php'; 

// 1. Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// 2. Fetch Pending Applications with Student and Event details
// We use JOIN to get the Student Name and Event Title in one go
$query = "SELECT volunteer_apps.id, volunteer_apps.user_id, volunteer_apps.status, 
                 users.fullname, users.university_id, 
                 events.title as event_name, events.id as eid
          FROM volunteer_apps 
          JOIN users ON volunteer_apps.user_id = users.id 
          JOIN events ON volunteer_apps.event_id = events.id 
          WHERE volunteer_apps.status = 'pending' 
          ORDER BY volunteer_apps.applied_at DESC";

$requests = mysqli_query($conn, $query);

if (!$requests) {
    die("Query Error: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Volunteers | EventGrid</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header"><h2>EventGrid</h2></div>
       <nav class="admin-nav">
    <a href="dashboard.php">Dashboard</a>
    <a href="createevent.php">Create Event</a>
    <a href="manageevent.php">Manage Events</a>
    <a href="manage_volunteers.php">Volunteer Requests</a>
    <!-- ADD THIS NEW LINE BELOW -->
    <a href="view_feedback.php">Review Feedback</a> 
    <!-- <hr style="border: 0.5px solid #2d3748; margin: 10px 0;"> -->
       <a href="manage_stalls.php">Stall Requests</a>
    <a href="../logout.php">Logout</a>
</nav>
    </div>

    <main class="admin-main">
        <div class="page-header">
            <h1>Volunteer Applications</h1>
            <p>Approve or reject students who want to volunteer for events.</p>
        </div>

        <?php if(isset($_GET['msg'])): ?>
            <div style="background:#d4edda; color:#155724; padding:10px; border-radius:5px; margin-bottom:20px;">
                ✅ <?php echo $_GET['msg']; ?>
            </div>
        <?php endif; ?>

        <div class="form-card" style="max-width: 100%;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>University ID</th>
                        <th>Target Event</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($requests) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($requests)): ?>
                            <tr>
                                <td><strong><?php echo $row['fullname']; ?></strong></td>
                                <td><?php echo $row['university_id']; ?></td>
                                <td><?php echo $row['event_name']; ?></td>
                                <td>
                                    <!-- We pass UID and EID so we can send the notification in the next step -->
                                    <a href="process_volunteer.php?id=<?php echo $row['id']; ?>&status=approved&uid=<?php echo $row['user_id']; ?>&ename=<?php echo urlencode($row['event_name']); ?>&eid=<?php echo $row['eid']; ?>" 
                                       style="color: #38a169; font-weight: bold; text-decoration: none; margin-right: 15px;">Approve</a>
                                    
                                    <a href="process_volunteer.php?id=<?php echo $row['id']; ?>&status=rejected&uid=<?php echo $row['user_id']; ?>&ename=<?php echo urlencode($row['event_name']); ?>&eid=<?php echo $row['eid']; ?>" 
                                       style="color: #e53e3e; font-weight: bold; text-decoration: none;">Reject</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align:center; padding:30px; color:gray;">No pending volunteer requests found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
</body>
</html>