<?php 
/** @var mysqli $conn */
require_once '../includes/db.php'; 

// 1. Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// 2. Get Event ID from URL
if (!isset($_GET['id'])) {
    header("Location: manageevent.php");
    exit();
}
$event_id = mysqli_real_escape_string($conn, $_GET['id']);

// 3. Fetch Event Name for the header
$event_res = mysqli_query($conn, "SELECT title FROM events WHERE id = '$event_id'");
$event_data = mysqli_fetch_assoc($event_res);

// 4. Fetch Registered Students (Now including reg_type)
// This query joins the users table and registrations table
$query = "SELECT users.fullname, users.university_id, users.department, users.email, 
                 registrations.reg_type, registrations.reg_date 
          FROM registrations 
          JOIN users ON registrations.user_id = users.id 
          WHERE registrations.event_id = '$event_id'
          ORDER BY registrations.reg_date DESC";

$participants = mysqli_query($conn, $query);

if (!$participants) {
    die("Query Error: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Participants | <?php echo $event_data['title']; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header"><h2>EventGrid</h2></div>
        <nav class="admin-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="manageevent.php" class="active">← Back to Events</a>
            <a href="manage_volunteers.php">Volunteer Requests</a>
            <a href="manage_stalls.php">Stall Requests</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="page-header">
            <h1>Student Registrations</h1>
            <p>Event: <strong><?php echo htmlspecialchars($event_data['title']); ?></strong></p>
        </div>

        <div class="form-card" style="max-width: 100%;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>University ID</th>
                        <th>Type</th> <!-- NEW COLUMN -->
                        <th>Department</th>
                        <th>Email</th>
                        <th>Reg. Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($participants) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($participants)): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($row['fullname']); ?></strong></td>
                                <td><?php echo htmlspecialchars($row['university_id']); ?></td>
                                <td>
                                    <!-- Dynamic Badge: Purple for Stall Holders, Blue for Participants -->
                                    <?php if($row['reg_type'] == 'Stall Holder'): ?>
                                        <span class="badge" style="background: #805ad5; color: white;">Stall Holder</span>
                                    <?php else: ?>
                                        <span class="badge" style="background: #3182ce; color: white;">Participant</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($row['department']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($row['reg_date'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 40px; color: gray;">
                                No students have joined this event yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

</body>
</html>