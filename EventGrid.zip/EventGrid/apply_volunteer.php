<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

if (!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }

$event_id = $_GET['eid'];
$user_id = $_SESSION['user_id'];

// Check if already applied
$check = mysqli_query($conn, "SELECT id FROM volunteer_apps WHERE event_id = '$event_id' AND user_id = '$user_id'");

if(mysqli_num_rows($check) > 0) {
    header("Location: dashboard.php?msg=You have already applied for this event!");
} else {
    $sql = "INSERT INTO volunteer_apps (event_id, user_id) VALUES ('$event_id', '$user_id')";
    mysqli_query($conn, $sql);
    header("Location: dashboard.php?msg=Application sent! Wait for Admin approval.");
}
?>