<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

if (!isset($_SESSION['role'])) { header("Location: index.php"); exit(); }

$uid = $_SESSION['user_id'];

// Fetch events joined by this student 
// We include events.food_coupon to check if the admin enabled it for that specific event
$query = "SELECT events.title, events.event_date, events.food_coupon AS event_has_food, 
                 registrations.food_coupon AS student_coupon_code, registrations.reg_date 
          FROM registrations 
          JOIN events ON registrations.event_id = events.id 
          WHERE registrations.user_id = '$uid'
          ORDER BY registrations.reg_date DESC";

$my_events = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Registrations | EventGrid</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="admin-body">
<div class="admin-wrapper">
    <!-- SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header"><h2>EventGrid</h2></div>
        <nav class="admin-nav">
            <a href="dashboard.php">🏠 Explore Events</a>
            <a href="my_registrations.php" class="active">📅 My Registrations</a>
            <a href="my_stalls.php">🛒 Stall Status</a>
            <a href="notification.php">🔔 Notifications</a>
            <a href="feedback.php">💬 Suggestions</a>
            <!-- <a href="about_us.php">ℹ️ About Us</a> -->
            <a href="logout.php">Logout</a>
        </nav>
    </div>

    <main class="admin-main">
        <div class="page-header">
            <h1>My Joined Events</h1>
            <p>Here are the events you have successfully registered for.</p>
        </div>

        <div class="student-event-grid">
            <?php if(mysqli_num_rows($my_events) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($my_events)): ?>
                    
                    <div class="student-event-card" style="border-top: 5px solid #2ecc71;">
                        <div class="card-text-content">
                            <h3 style="margin-bottom: 5px;"><?php echo htmlspecialchars($row['title']); ?></h3>
                            <p style="font-size: 0.85rem; color: gray; margin-bottom: 15px;">
                                📅 Event Date: <?php echo date('M d, Y', strtotime($row['event_date'])); ?>
                            </p>

                            <!-- LOGIC FIX: Only show coupon if event_has_food is 1 -->
                            <?php if($row['event_has_food'] == 1): ?>
                                <div style="background: #e8f5e9; padding: 15px; border-radius: 10px; border: 1px dashed #2ecc71;">
                                    <small style="color: #27ae60; font-weight: bold; text-transform: uppercase; font-size: 0.7rem;">Food Coupon Code</small>
                                    <strong style="display: block; color: #1b5e20; font-size: 1.3rem; letter-spacing: 1px;">
                                        <?php echo $row['student_coupon_code']; ?>
                                    </strong>
                                </div>
                            <?php else: ?>
                                <div style="background: #f7fafc; padding: 15px; border-radius: 10px; border: 1px solid #edf2f7; text-align: center;">
                                    <p style="color: #a0aec0; font-size: 0.85rem; margin: 0;">No food coupon for this event.</p>
                                </div>
                            <?php endif; ?>

                            <p style="font-size: 0.75rem; color: #cbd5e0; margin-top: 15px;">
                                Registered on: <?php echo date('M d, Y', strtotime($row['reg_date'])); ?>
                            </p>
                        </div>
                    </div>

                <?php endwhile; ?>
            <?php else: ?>
                <div style="grid-column: span 2; text-align: center; padding: 50px; background: white; border-radius: 15px;">
                    <p>You haven't joined any events yet.</p>
                    <a href="dashboard.php" style="color: #3182ce; text-decoration: none; font-weight: bold;">Browse Events →</a>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>