<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

// 1. If user is already logged in, send them to their dashboard immediately
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: dashboard.php");
    }
    exit();
}

$error = "";

// 2. Handle Login Form Submission
if (isset($_POST['login_btn'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // Search for user by email
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // Verify Password
        if (password_verify($password, $user['password'])) {
            // LOGIN SUCCESS: Store user info in Session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['fullname'];
            $_SESSION['role'] = $user['role']; // MUST be 'admin' or 'student'

            // REDIRECT based on role
            if ($user['role'] == 'admin') {
                header("Location: admin/dashboard.php");
            } else {
                header("Location: dashboard.php");
            }
            exit();
        } else {
            $error = "Incorrect password. Please try again.";
        }
    } else {
        $error = "No account found with that email.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | EventGrid</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">

    <div class="login-container">
        <div class="login-box">
            <h1>EventGrid</h1>
            <!-- <p>University Event Management System</p> -->
            <hr>

            <?php if($error): ?>
                <p style="color:red; background:#ffdada; padding:10px; border-radius:5px;"><?php echo $error; ?></p>
            <?php endif; ?>

            <?php if(isset($_GET['success'])): ?>
                <p style="color:green; background:#d4edda; padding:10px; border-radius:5px;"><?php echo $_GET['success']; ?></p>
            <?php endif; ?>

            <form action="index.php" method="POST">
                <div class="input-group">
                    <label>University Email</label>
                    <input type="email" name="email" placeholder="email@varsity.edu" required>
                </div>

                <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter your password" required>
                </div>

                <button type="submit" name="login_btn" class="btn-login">Sign In</button>
            </form>

            
            
    <p>Don't have an account? <a href="register.php">Register here</a></p>
    <!-- ADD THIS LINE BELOW -->
    <p style="margin-top: 10px;">
        <a href="about_us.php" style="font-size: 0.85rem; color: #718096; text-decoration: none;">
            ℹ️ Learn more about EventGrid
        </a>
    </p>
</div>
            </div>
        </div>
    </div>

</body>
</html>