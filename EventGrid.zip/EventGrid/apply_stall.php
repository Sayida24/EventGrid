<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

if (!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }
$event_id = $_GET['eid']; // Get from URL
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Stall Booking | EventGrid</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="admin-body">
<div class="admin-wrapper">
    <div class="admin-sidebar"> <!-- Your standard student sidebar --> </div>
    
    <main class="admin-main">
        <div class="form-card" style="max-width: 600px;">
            <h1>Startup Stall Application</h1>
            <p style="margin-bottom: 20px; color: gray;">Admin will review your business info before approval.</p>

            <form action="process_stall_apply.php" method="POST">
                <input type="hidden" name="event_id" value="<?php echo $event_id; ?>">

                <div class="form-group">
                    <label>Business / Page Name</label>
                    <input type="text" name="page_name" required placeholder="Enter your business name">
                </div>

                <div class="form-group">
                    <label>Facebook Page Link</label>
                    <input type="url" name="fb_link" required placeholder="https://facebook.com/yourshop">
                </div>

                <div class="form-group">
                    <label>Product Details</label>
                    <textarea name="product_details" required placeholder="What are you selling? (e.g., Handmade jewelry, tech gadgets)"></textarea>
                </div>

                <div class="form-group">
                    <label>Where do you purchase/source your products?</label>
                    <input type="text" name="purchase_place" required placeholder="e.g., Local wholesalers, imported, self-made">
                </div>

                <!-- <button type="submit" name="submit_app" class="btn-publish">Submit for Verification</button> -->

                <button type="submit" name="submit_stall" class="btn-publish">Submit Application</button>
            </form>
        </div>
    </main>
</div>
</body>
</html>