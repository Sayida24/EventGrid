<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

if(!isset($_GET['app_id'])) { header("Location: dashboard.php"); exit(); }
$app_id = $_GET['app_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Payment Gateway | EventGrid</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">

<div class="login-container">
    <div class="login-box">
        <h2 style="color: #d53f8c;">Nagad / bKash Payment</h2>
        <p style="margin-bottom: 20px;">Stall Booking Fee: <strong>500 BDT</strong></p>
        
        <div style="background: #fff5f7; padding: 15px; border-radius: 8px; margin-bottom: 20px; text-align: left; border: 1px solid #feb2b2;">
            <p>1. Send 500 BDT to <strong>01700-000000</strong></p>
            <p>2. Use "Stall" as reference</p>
            <p>3. Enter Transaction ID below</p>
        </div>

        <form action="confirm_payment.php" method="POST">
            <input type="hidden" name="app_id" value="<?php echo $app_id; ?>">
            <div class="input-group">
                <label>Transaction ID (TrxID)</label>
                <input type="text" name="trx_id" placeholder="e.g. 8N7X6W5V4" required>
            </div>
            <button type="submit" name="confirm_pay" class="btn-login" style="background: #d53f8c;">Verify Payment</button>
        </form>
    </div>
</div>

</body>
</html>