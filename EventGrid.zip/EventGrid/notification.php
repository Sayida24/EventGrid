<?php 
/** @var mysqli $conn */
require_once 'includes/db.php'; 

// 1. Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// 2. FETCH MERGED NOTIFICATIONS (Now including event_id)
// We take event_id so we can link to the specific event details
$query = "(SELECT message, event_id, created_at, 'global' as type FROM notifications) 
          UNION 
          (SELECT message, event_id, created_at, 'personal' as type FROM user_notifications WHERE user_id = '$user_id') 
          ORDER BY created_at DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notifications | EventGrid</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Small style addition to make the link look like a card */
        .notif-link {
            text-decoration: none;
            display: block;
            margin-bottom: 15px;
            transition: 0.2s;
        }
        .notif-link:hover .notif-card {
            background-color: #f7fafc;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- STUDENT SIDEBAR -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2>EventGrid</h2>
            <p>Student Portal</p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php">🏠 Explore Events</a>
            <a href="my_registrations.php">📅 My Registrations</a>
             <a href="my_stalls.php">🛒 Stall Status</a>
            <a href="notification.php" class="active">🔔 Notifications</a>
            <a href="feedback.php">💬 Suggestions</a>
           
            <a href="logout.php">🚪 Logout</a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="admin-main">
        <div class="notif-container">
            <div class="page-header">
                <h1>Campus Notifications</h1>
                <p>Click on any alert to view the event details.</p>
            </div>

            <div class="notif-feed">
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        
                        <!-- 3. WRAP THE NOTIFICATION IN A CLICKABLE LINK -->
                        <a href="event_details.php?id=<?php echo $row['event_id']; ?>" class="notif-link">
                            
                            <div class="notif-card" style="<?php echo ($row['type'] == 'personal') ? 'border-left-color: #38a169;' : ''; ?>">
                                
                                <div class="notif-icon-circle" style="<?php echo ($row['type'] == 'personal') ? 'background: #f0fff4; color: #38a169;' : ''; ?>">
                                    <?php echo ($row['type'] == 'personal') ? '✅' : '🔔'; ?>
                                </div>

                                <div class="notif-content">
                                    <p>
                                        <?php if($row['type'] == 'personal'): ?>
                                            <strong style="color: #38a169;">Personal Alert:</strong> 
                                        <?php endif; ?>
                                        <?php echo htmlspecialchars($row['message']); ?>
                                    </p>
                                    <span class="notif-time">
                                        <?php echo date('M d, Y | h:i A', strtotime($row['created_at'])); ?>
                                    </span>
                                    <small style="color: #3182ce; font-weight: 600; display: block; margin-top: 5px;">Click to view event details →</small>
                                </div>
                            </div>

                        </a>

                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 50px; background: white; border-radius: 15px;">
                        <p>No notifications yet. You're all caught up!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

</body>
</html>