<div class="login-box">
    <h2>Pay 500 BDT for Stall</h2>
    <p>Send money to: 017XXXXXXXX (Bkash/Nagad)</p>
    <form action="complete_payment.php" method="POST">
        <input type="text" name="trx_id" placeholder="Enter Transaction ID" required>
        <button type="submit" class="btn-login">Confirm Payment</button>
    </form>
</div>