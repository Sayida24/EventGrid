-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2026 at 06:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventgrid_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `event_type` enum('Seminar','Startup Market','Cultural','Convocation','Orientation','Concert') NOT NULL,
  `poster` varchar(255) DEFAULT NULL,
  `participant_types` varchar(100) DEFAULT NULL,
  `food_coupon` tinyint(1) DEFAULT 0,
  `stall_limit` int(11) DEFAULT 0,
  `performance_categories` varchar(255) DEFAULT NULL,
  `volunteer_limit` int(11) DEFAULT 0,
  `volunteers_needed` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `description`, `event_date`, `event_time`, `location`, `created_by`, `event_type`, `poster`, `participant_types`, `food_coupon`, `stall_limit`, `performance_categories`, `volunteer_limit`, `volunteers_needed`) VALUES
(12, 'Campus to career: bridging the future', NULL, '2026-04-30', '00:00:00', 'International Conference Hall', NULL, 'Seminar', '1776784404_WhatsApp Image 2026-04-21 at 8.43.30 PM.jpeg', 'Student, Guest', 1, 0, NULL, 10, 1),
(13, 'Oitijjer Hat', NULL, '2026-04-22', '00:00:00', 'Auditorium', NULL, 'Cultural', '1776784452_WhatsApp Image 2026-04-21 at 8.33.30 PM.jpeg', 'Student', 0, 0, NULL, 0, 0),
(14, 'Boisakhi Mela', NULL, '2026-04-24', '00:00:00', 'Auditorium', NULL, 'Cultural', '1776784504_WhatsApp Image 2026-04-21 at 8.24.50 PM.jpeg', 'Student, Faculty, Guest', 0, 0, NULL, 0, 0),
(15, 'Startup Market', NULL, '2026-04-25', '00:00:00', 'AB4 Lobby', NULL, 'Startup Market', '1776784560_WhatsApp Image 2026-04-21 at 8.24.13 PM.jpeg', 'Student', 0, 0, NULL, 0, 0),
(16, 'seminar', NULL, '2026-04-23', '00:00:00', 'Auditorium', NULL, 'Seminar', '1776789469_WhatsApp Image 2026-04-21 at 8.24.13 PM.jpeg', 'Student, Faculty, Guest', 1, 0, NULL, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `suggestions` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `event_id`, `user_id`, `comment`, `suggestions`) VALUES
(2, NULL, 6, 'Arrange more seminars', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `message`, `event_id`, `created_at`) VALUES
(11, 'New Event Added: Campus to career: bridging the future', 12, '2026-04-21 15:13:24'),
(12, 'New Event Added: Oitijjer Hat', 13, '2026-04-21 15:14:12'),
(13, 'New Event Added: Boisakhi Mela', 14, '2026-04-21 15:15:04'),
(14, 'New Event Added: Startup Market', 15, '2026-04-21 15:16:00'),
(15, 'New Event Added: seminar', 16, '2026-04-21 16:37:49');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `food_coupon` varchar(50) DEFAULT NULL,
  `reg_type` varchar(50) DEFAULT 'Participant'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`id`, `user_id`, `event_id`, `reg_date`, `food_coupon`, `reg_type`) VALUES
(11, 6, 14, '2026-04-21 15:17:47', 'GRID-8083-sa', 'Participant'),
(12, 6, 13, '2026-04-21 15:17:59', 'GRID-7939-sa', 'Participant');

-- --------------------------------------------------------

--
-- Table structure for table `stall_applications`
--

CREATE TABLE `stall_applications` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `page_name` varchar(255) DEFAULT NULL,
  `fb_link` varchar(255) DEFAULT NULL,
  `product_details` text DEFAULT NULL,
  `purchase_place` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `payment_status` enum('unpaid','paid') DEFAULT 'unpaid',
  `trx_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stall_applications`
--

INSERT INTO `stall_applications` (`id`, `event_id`, `user_id`, `page_name`, `fb_link`, `product_details`, `purchase_place`, `status`, `payment_status`, `trx_id`, `created_at`) VALUES
(5, 15, 6, 'ShopDrop', 'https://www.facebook.com/share/v/18c6xf4X8B/', 'Comsmetic Products', 'Foreign Countries', 'approved', 'unpaid', NULL, '2026-04-21 15:17:29');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `university_id` varchar(50) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','admin') DEFAULT 'student',
  `last_seen_event_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `university_id`, `department`, `email`, `password`, `role`, `last_seen_event_id`) VALUES
(6, 'sagor', '232432', 'Engineering', 'parvin23053412833333@diu.edu.bd', '$2y$10$c7OiKoK3pl1jcoG3oa/fRuWF/RG5W8zqBKcbiNxDM1ls9sCo9GzTy', 'student', 15),
(7, 'sagor', '2222', 'Engineering', 'SA12@gmail.com', '$2y$10$/H./xk1v6t8yV6wgO.tmceM45VHif8wH5iS3kJdAljNb1/GvoPwRe', 'student', 15),
(8, 'abc', '24493439', 'Administration', 'Alisha+proyash@gmail.com', '$2y$10$xEiQXl/jE2aaOqmHjfBxaOLg3kNFfOpdj8Tvydx1Y1nBPKq/Q2hzW', 'admin', 0),
(9, 'Sayida Parvin', '12345', 'Administration', 'parvin2305341280@diu.edu.bd', '$2y$10$MfqwtxtBsERRnO1CA/YvXe.fKYw6GoWMML.Ts2kAH.GBUWt3iOD/2', 'admin', 0),
(10, 'Sayida Parvin', '123456', 'Administration', 'sayida12@gmail.com', '$2y$10$0XyYlrEoSZQPU7Iy/F/G4OaMxZSBu3zyRHlH.BMupdcx6RaczCBYe', 'admin', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `is_read` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_seen` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_notifications`
--

INSERT INTO `user_notifications` (`id`, `user_id`, `message`, `event_id`, `is_read`, `created_at`, `is_seen`) VALUES
(7, 6, 'Congratulations! You are approved as a volunteer for: Campus to career: bridging the future', 12, 0, '2026-04-21 16:38:58', 0),
(8, 6, 'Congratulations! Your Startup Stall has been SELECTED. Please proceed to payment to confirm your booking.', 15, 0, '2026-04-21 16:39:16', 0);

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `status` enum('pending','approved') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_apps`
--

CREATE TABLE `volunteer_apps` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteer_apps`
--

INSERT INTO `volunteer_apps` (`id`, `event_id`, `user_id`, `status`, `applied_at`) VALUES
(3, 12, 6, 'approved', '2026-04-21 15:17:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `stall_applications`
--
ALTER TABLE `stall_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `student_id` (`university_id`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `volunteer_apps`
--
ALTER TABLE `volunteer_apps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `stall_applications`
--
ALTER TABLE `stall_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `volunteer_apps`
--
ALTER TABLE `volunteer_apps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `registrations`
--
ALTER TABLE `registrations`
  ADD CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `registrations_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`);

--
-- Constraints for table `stall_applications`
--
ALTER TABLE `stall_applications`
  ADD CONSTRAINT `stall_applications_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `stall_applications_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD CONSTRAINT `user_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD CONSTRAINT `volunteers_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  ADD CONSTRAINT `volunteers_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `volunteer_apps`
--
ALTER TABLE `volunteer_apps`
  ADD CONSTRAINT `volunteer_apps_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  ADD CONSTRAINT `volunteer_apps_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
